package com.example.examenandroid.Controlador;

import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.examenandroid.Modelo.Informe;
import com.example.examenandroid.MainActivity;
import com.example.examenandroid.R;
import com.example.examenandroid.llenarCampos;


/**
 *Conecta las clases main y peticiones
 */

public class Controlador {
    //ESTADO

    //Enlace a MainActivity
    protected MainActivity miActivity;

    Informe petition;
    //Instancia singleton
    private static Controlador miControlador;
    private PreView pv;
    //COMPORTAMIENTO

    //Constructor. Privado
    private Controlador() {

    }

    //Método de acceso
    public static Controlador getInstance() {
        if (miControlador == null)
                miControlador = new Controlador();
        return miControlador;
    }

    public void getPrevision(MainActivity fromActivity, String localidad) {
        Peticion miPeticion = new Peticion();
        String url = "https://opendata.aemet.es/opendata/api/prediccion/maritima/altamar/area/"
                  + localidad
                + "?api_key=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqYXZpZXJmcm9jaG9zb2dhcmNpYUBnbWFpbC5jb20iLCJqdGkiOiJmZDY3ZjUzOS1lYmJjLTQ0OGUtYjNmYS01MThjYzMzOTE1NmUiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTY3NTA5NjUzNywidXNlcklkIjoiZmQ2N2Y1MzktZWJiYy00NDhlLWIzZmEtNTE4Y2MzMzkxNTZlIiwicm9sZSI6IiJ9.U983DRABR-JN4kbe5iWoGPytDd6re97HyKyQQg8g9Us";
        //Enlazamos con la Activity que hace la llamada, para devolverle los datos cuando
        //los tengamos

        this.miActivity = fromActivity;

        miPeticion.getPrevision(url);
    }

    public void setRespuestaAPeticion(String respuesta, int turno) {
        Respuesta miRespuesta = new Respuesta(respuesta, turno);

        if (turno == 1) {
            //Hay que volver a pedir
            Peticion miPeticion = new Peticion();
            String url = miRespuesta.getUrl();
            //Enlazamos con la Activity que hace la llamada, para devolverle los datos cuando
            //los tengamos

            miPeticion.getPrevision(url);
        } else if (turno == 0){

            //Recibe el json rellena el RecyclerView
            pv=new PreView(miActivity,miRespuesta.getInforme());

        } else {
            pv=new PreView(miActivity,miRespuesta.getInforme());
        }


    }


    //Añade los contenidos del spìnner
    public SpinnerAdapter getLocalidades() {

        ArrayAdapter<String> miSpinnerAdapter = new ArrayAdapter<>(miActivity, android.R.layout.simple_spinner_item);
        miSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        miSpinnerAdapter.add("Seleccionar Zona");
        miSpinnerAdapter.add("Atlántico al sur de 35ºN");
        miSpinnerAdapter.add("Atlántico al norte de 30ºN");
        miSpinnerAdapter.add("Mar mediterráneo");

        return miSpinnerAdapter;
    }

    //Define la actividad
    public void setActivity(MainActivity act) {
        miActivity = act;
    }

}
