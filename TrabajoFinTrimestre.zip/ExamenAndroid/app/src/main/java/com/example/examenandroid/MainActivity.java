package com.example.examenandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.examenandroid.Controlador.Controlador;
import com.example.examenandroid.Controlador.Peticion;
import com.example.examenandroid.Modelo.Informe;

import java.io.IOException;

//Implementa la clase AdapterView, que permite manipular el recycler view y extiende a los métodos
//App compact
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    RecyclerView recycler;
    Informe peticion;
    Controlador controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Define el xml de vistas
        setContentView(R.layout.activity_v3_layout);

        /*+
        * Define la clase controlador para sacar la instancia
        * */
        controller = Controlador.getInstance();
        //define la actividad principal.
        controller.setActivity(this);

        //Define el spinner
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);
        spinner.setAdapter(Controlador.getInstance().getLocalidades());

    }

    //cuando se selecciona un elemento del spinner, se ejecuta una petición donde se manda como parámetro
    //Un número dependiendo del archivo json que se quiera analizar.
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String zoneSelected = (String) ((Spinner) parent).getAdapter().getItem(position);
        switch (zoneSelected) {
            case "Seleccionar Zona":
                ((TextView) this.findViewById(R.id.fechaInic)).setText(" ");
                ((TextView) this.findViewById(R.id.fechaFin)).setText(" ");
                break;
            case "Atlántico al sur de 35ºN":
                controller.getPrevision(this, "0");
                break;
            case "Atlántico al norte de 30ºN":
                controller.getPrevision(this, "1");
                break;
            case "Mar mediterráneo":
                controller.getPrevision(this, "2");
                break;
        }
    }

    //No se programa nada para cuando no hay elección en el spìnner
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    //Para que finalice la actividad.
    @Override
    protected void onDestroy() {
        super.onDestroy();
//        Controlador.getInstance().closeAllAtEnding();
    }
}