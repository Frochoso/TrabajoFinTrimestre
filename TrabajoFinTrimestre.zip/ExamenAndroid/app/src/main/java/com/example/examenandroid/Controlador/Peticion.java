package com.example.examenandroid.Controlador;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Clase Peticion
 *
 * El controlador le pasa los datos a la petición y esta los manda a respuesta.
 */
public class Peticion {

    static protected int turno = 0;

    public Peticion() {

    }

    public void getPrevision(String URL) {
        if (URL == null) {
            Controlador.getInstance().setRespuestaAPeticion("", Peticion.turno);
            return;
        }

        OkHttpClient cliente = new OkHttpClient();
        final int nuevoTurno = (Peticion.turno + 1) % 2;
        Peticion.turno = nuevoTurno;

        Request peticion = new Request.Builder()
                .url(URL)
                .get()
                .addHeader("cache-control", "no-cache")
                .build();

        Call llamada = cliente.newCall(peticion);
        llamada.enqueue(new Callback() {
            public void onResponse(@NonNull Call call, @NonNull Response respuestaServer)
                    throws IOException {
                String respuesta = respuestaServer.body().string();
                Handler manejador = new Handler(Looper.getMainLooper());

                manejador.post(() -> {
                    Controlador miControlador = Controlador.getInstance();
                    miControlador.setRespuestaAPeticion(respuesta, nuevoTurno);
                });
            }

            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Handler manejador = new Handler(Looper.getMainLooper());

                manejador.post(() -> {
                    Controlador miControlador = Controlador.getInstance();
                    miControlador.setRespuestaAPeticion("", -1);
                });
            }
        });
    }
}

