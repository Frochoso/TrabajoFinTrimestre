package com.example.examenandroid.Controlador;

import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.examenandroid.MainActivity;
import com.example.examenandroid.Modelo.Informe;
import com.example.examenandroid.R;
import com.example.examenandroid.llenarCampos;


//rellena el contenido de los textviews y RecyclerView
public class PreView {

    private Informe informe;
    private llenarCampos adapter;

    //Permite rellenar el recyclerView, recibe el json y lo parsea
    public PreView(MainActivity activity, String json){
        RecyclerView recycler=activity.findViewById(R.id.recyclerV);
        informe =new Informe(json);
        ((TextView) activity.findViewById(R.id.fechaInic)).setText(informe.Inicio());
        ((TextView) activity.findViewById(R.id.fechaFin)).setText(informe.Fin());
        adapter=new llenarCampos(activity,getInforme());
        //Define el layout, la orientación y que no sea invertido.
        recycler.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false));
        recycler.setAdapter(adapter);
    }

    public Informe getInforme(){
        return informe;
    }
}
