package com.example.examenandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.examenandroid.Modelo.Clima;
import com.example.examenandroid.Modelo.Informe;

import java.util.ArrayList;

/**
 * Clase adaptador que permite el correcto funcionamiento del
 * RecyclerView.
 */
public class llenarCampos extends RecyclerView.Adapter<llenarCampos.WordViewHolder>{

    //Se definen los atributos que va a recibir el adaptador
    private Informe mInforme;
    private LayoutInflater mInflater;

    //Constructor del adaptador
    public llenarCampos(Context context, Informe personajes){
        mInflater= LayoutInflater.from(context);
        mInforme=personajes;
    }


    //Une el layout con el recycler.
    @NonNull
    @Override
    public llenarCampos.WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mItemView= mInflater.inflate(R.layout.adapter, parent,false);
        return new WordViewHolder(mItemView,this);
    }

    /*
    Indica al recycler el contenido correspondiente en cada textView cogiendolo del controlador
     */
    @Override
    public void onBindViewHolder(@NonNull WordViewHolder holder, int position) {
        Clima mCurrent= mInforme.zonasArray().get(position);
        holder.name.setText(mCurrent.nombre());
        holder.id.setText(mCurrent.id());
        holder.text.setText(mCurrent.texto());
    }


    /*
    Devuelve el número total de items en el data set del adapter
     */
    @Override
    public int getItemCount() {
        return mInforme.zonasArray().size();
    }


    /**
     *Define los itemView que se encuentran en el layout del adaptador
     */
    class WordViewHolder extends RecyclerView.ViewHolder {
        public TextView name,text,id;
        final llenarCampos mAdaptador;

        public WordViewHolder(View itemView, llenarCampos adaptador) {
            super(itemView);
            name=itemView.findViewById(R.id.name);
            text=itemView.findViewById(R.id.text);
            id=itemView.findViewById(R.id.id);
            this.mAdaptador = adaptador;
        }
    }
}
