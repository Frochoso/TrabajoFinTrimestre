package com.example.examenandroid.Controlador;
import com.example.examenandroid.Controlador.ResultadoMunicipio;
import com.google.gson.Gson;

/**
 * Clase respuesta. Encapsulará los datos que nos devuelve la API REST
 * opendata de la AEMET.
 *
 * Recibe la información de api, devuelve el json.
 */


//
public class Respuesta {
    //ESTADO
    protected String datos;
    protected int turno;

    //COMPORTAMIENTO
    public Respuesta(String entrada, int turno) {

        datos = entrada;
        this.turno = turno;
    }

    public String getInforme() {
        return datos;
    }

    //Devuelve la url a parsear
    public String getUrl() {
        //id del turno, devuelve el resultado con 5 variables
        //1 de ellas esta el link con los datos
        //Accede a ellos y los devuelve
        ResultadoMunicipio intermedio;
        String url = "";

        if (datos.isEmpty()) {
            return "";
        }

        Gson miGsonRespuesta = new Gson();
        if (turno == 1) {
            intermedio = miGsonRespuesta.fromJson(datos, ResultadoMunicipio.class);
            url = intermedio.getDatos();
        } else
            url = datos.substring(datos.indexOf("https://www.aemet.es/es/eltiempo"), datos.indexOf("language") - 8);

        return url;
    }
}
