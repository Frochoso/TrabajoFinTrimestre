package com.example.examenandroid.Modelo;

import com.google.gson.JsonElement;

/**
 * Clase para poder rellenar los valores de un ArrayList y poder parsear.
 */

public class Clima {

    private String texto,id,nombre;

    public Clima(JsonElement element){
        this.texto=element.getAsJsonObject().getAsJsonPrimitive("texto").getAsString();
        this.id=element.getAsJsonObject().getAsJsonPrimitive("id").getAsString();
        this.nombre=element.getAsJsonObject().getAsJsonPrimitive("nombre").getAsString();
    }

    public String texto() {
        return texto;
    }

    public String id() {
        return id;
    }

    public String nombre() {
        return nombre;
    }

    public String toString(){
        return "Texto: "+texto+
                ". id: "+id+
                ". Nombre: "+nombre+".";
    }
}
