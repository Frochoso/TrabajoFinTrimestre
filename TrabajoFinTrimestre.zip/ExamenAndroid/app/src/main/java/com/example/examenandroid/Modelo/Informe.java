package com.example.examenandroid.Modelo;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;

public class Informe {
    /**
     * Recibe el json y lo parsea, devuelve individualmente los contenidos de los
     * fenómenos meteorológicos y las fechas.
     */
    private ArrayList<Clima>zonasArray=new ArrayList<>();
private String Inicio,Fin;

    //
    public Informe(String json){
        JsonElement informe= JsonParser.parseString(json);
        JsonArray datos=informe.getAsJsonArray();
        JsonObject obj1=datos.get(0).getAsJsonObject();
        JsonObject prediccion=obj1.get("prediccion").getAsJsonObject();
        this.Inicio=prediccion.get("inicio").getAsString();
        this.Fin=prediccion.get("fin").getAsString();
        JsonElement zonas=prediccion.get("zona");
        JsonArray array1=zonas.getAsJsonArray();

        for(JsonElement p:array1){
            zonasArray.add(new Clima(p));
        }

    }

    public ArrayList<Clima> zonasArray() {
        return zonasArray;
    }

    public String Inicio() {
        return Inicio;
    }

    public String Fin() {
        return Fin;
    }
}
